Example of critcl-based packages.

A larger example written to demonstrate

	Easy writing of C classes, with class and instances
	represented as commands, through the utility package
	critcl::class

Sources
	Package "queuec":	queuec.tcl, queuec/*.[ch]

Notes:
	--
