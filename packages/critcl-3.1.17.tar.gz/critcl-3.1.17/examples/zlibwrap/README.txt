Example of critcl-based packages.

A larger example written to demonstrate

	Export of an API from an external 3rd party library as Tcl stubs table.
	Build switchability between
		linking a system instance of the 3rd party library
	and	building a static library from local sources and
		linking against this.

Sources
	Package "zlib":			zlib.tcl
	Local sources of C zlib:	zlib/

Notes:
